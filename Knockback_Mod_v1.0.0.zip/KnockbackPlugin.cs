using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;

namespace KnockbackMod
{
    [BepInPlugin("com.uchknockback.mod", "UCH Knockback Mod", "1.0.0")]
    public class KnockbackPlugin : BaseUnityPlugin
    {
        public static new ManualLogSource Logger { get; private set; }
        public static ConfigEntry<float> KnockbackForce { get; private set; }
        public static ConfigEntry<float> KnockbackRadius { get; private set; }
        public static ConfigEntry<bool> EnableMod { get; private set; }
        public static ConfigEntry<KeyCode> KnockbackKey { get; private set; }
        
        private Harmony harmony;
        private static KnockbackPlugin instance;
        
        private void Awake()
        {
            instance = this;
            Logger = base.Logger;
            
            // Configuration
            EnableMod = Config.Bind("General", "EnableMod", true, "Enable/Disable the knockback mod");
            KnockbackForce = Config.Bind("Knockback", "Force", 15f, "Force of the knockback (higher = stronger push)");
            KnockbackRadius = Config.Bind("Knockback", "Radius", 3f, "Radius of knockback effect");
            KnockbackKey = Config.Bind("Controls", "KnockbackKey", KeyCode.Mouse0, "Key to trigger knockback (Mouse0 = Left Click)");
            
            Logger.LogInfo($"UCH Knockback Mod v1.0.0 is loaded!");
            
            // Apply Harmony patches
            harmony = new Harmony("com.uchknockback.mod");
            harmony.PatchAll();
            
            Logger.LogInfo("Harmony patches applied successfully!");
        }
        
        private void Update()
        {
            if (!EnableMod.Value) return;
            
            if (Input.GetKeyDown(KnockbackKey.Value))
            {
                ApplyKnockbackFromLocalPlayer();
            }
        }
        
        private void ApplyKnockbackFromLocalPlayer()
        {
            try
            {
                // Try to find the local player's position
                GameObject localPlayer = FindLocalPlayer();
                if (localPlayer != null)
                {
                    Vector3 playerPos = localPlayer.transform.position;
                    ApplyKnockbackToNearbyPlayers(playerPos, localPlayer);
                    Logger.LogInfo($"Knockback triggered from player at position {playerPos}");
                }
                else
                {
                    Logger.LogWarning("Could not find local player for knockback");
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in ApplyKnockbackFromLocalPlayer: {ex}");
            }
        }
        
        private GameObject FindLocalPlayer()
        {
            // Look for common player object patterns
            GameObject[] candidates = GameObject.FindObjectsOfType<GameObject>();
            
            foreach (GameObject obj in candidates)
            {
                string name = obj.name.ToLower();
                if ((name.Contains("player") || name.Contains("character")) && 
                    obj.activeInHierarchy && 
                    obj.transform.position != Vector3.zero)
                {
                    // Check if this object has player-like components
                    if (HasPlayerComponents(obj))
                    {
                        return obj;
                    }
                }
            }
            
            return null;
        }
        
        private bool HasPlayerComponents(GameObject obj)
        {
            // Check for common player components
            return obj.GetComponent<Rigidbody2D>() != null ||
                   obj.GetComponent<Rigidbody>() != null ||
                   obj.GetComponent<CharacterController>() != null ||
                   obj.GetComponent<Collider2D>() != null ||
                   obj.GetComponent<Collider>() != null;
        }
        
        private void ApplyKnockbackToNearbyPlayers(Vector3 sourcePosition, GameObject sourcePlayer)
        {
            try
            {
                GameObject[] allObjects = GameObject.FindObjectsOfType<GameObject>();
                int playersAffected = 0;
                
                foreach (GameObject obj in allObjects)
                {
                    if (obj == sourcePlayer) continue; // Don't knockback self
                    
                    if (IsLikelyPlayer(obj))
                    {
                        float distance = Vector3.Distance(sourcePosition, obj.transform.position);
                        
                        if (distance <= KnockbackRadius.Value && distance > 0.1f)
                        {
                            if (ApplyKnockbackToPlayer(obj, sourcePosition))
                            {
                                playersAffected++;
                            }
                        }
                    }
                }
                
                Logger.LogInfo($"Applied knockback to {playersAffected} nearby players");
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in ApplyKnockbackToNearbyPlayers: {ex}");
            }
        }
        
        private bool IsLikelyPlayer(GameObject obj)
        {
            if (!obj.activeInHierarchy) return false;
            
            string name = obj.name.ToLower();
            return (name.Contains("player") || name.Contains("character")) && 
                   HasPlayerComponents(obj);
        }
        
        private bool ApplyKnockbackToPlayer(GameObject player, Vector3 sourcePosition)
        {
            try
            {
                Vector3 direction = (player.transform.position - sourcePosition).normalized;
                
                // Try Rigidbody2D first (most common for 2D games like UCH)
                Rigidbody2D rb2d = player.GetComponent<Rigidbody2D>();
                if (rb2d != null)
                {
                    Vector2 force2D = new Vector2(direction.x, direction.y) * KnockbackForce.Value;
                    rb2d.AddForce(force2D, ForceMode2D.Impulse);
                    Logger.LogInfo($"Applied 2D knockback to {player.name} with force {force2D}");
                    return true;
                }
                
                // Try Rigidbody for 3D
                Rigidbody rb = player.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    Vector3 force3D = direction * KnockbackForce.Value;
                    rb.AddForce(force3D, ForceMode.Impulse);
                    Logger.LogInfo($"Applied 3D knockback to {player.name} with force {force3D}");
                    return true;
                }
                
                // Fallback: Direct position manipulation
                Vector3 knockbackOffset = direction * (KnockbackForce.Value * 0.1f);
                player.transform.position += knockbackOffset;
                Logger.LogInfo($"Applied position knockback to {player.name} with offset {knockbackOffset}");
                return true;
                
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error applying knockback to {player.name}: {ex}");
                return false;
            }
        }
        
        private void OnDestroy()
        {
            harmony?.UnpatchSelf();
        }
    }
}
