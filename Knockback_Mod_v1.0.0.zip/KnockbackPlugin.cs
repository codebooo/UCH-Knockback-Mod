using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using UnityEngine;
using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine.SceneManagement;

namespace KnockbackMod
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class KnockbackPlugin : BaseUnityPlugin
    {
        internal const string PluginGuid = "com.uchknockback.mod";
        internal const string PluginName = "UCH Knockback Mod";
        internal const string PluginVersion = "1.0.1";

        public static new ManualLogSource Logger { get; private set; }
        public static ConfigEntry<float> KnockbackForce { get; private set; }
        public static ConfigEntry<float> KnockbackRadius { get; private set; }
        public static ConfigEntry<bool> EnableMod { get; private set; }
        public static ConfigEntry<KeyCode> KnockbackKey { get; private set; }
        public static ConfigEntry<bool> DebugLogging { get; private set; }

        private static KnockbackPlugin instance;
        private bool _pendingKnockback;
        private string _cachedSceneName;
        private GameObject _localPlayer;
        private readonly Collider2D[] _hits2D = new Collider2D[32];
        private readonly Collider[] _hits3D = new Collider[32];
        private readonly Collider2D[] _localSearchHits2D = new Collider2D[32];
        private readonly Collider[] _localSearchHits3D = new Collider[32];

        private void Awake()
        {
            instance = this;
            Logger = base.Logger;

            // Configuration
            EnableMod = Config.Bind("General", "EnableMod", true, "Enable/Disable the knockback mod");
            KnockbackForce = Config.Bind(
                "Knockback",
                "Force",
                15f,
                new ConfigDescription(
                    "Force of the knockback (higher = stronger push)",
                    new AcceptableValueRange<float>(0f, 100f)));
            KnockbackRadius = Config.Bind(
                "Knockback",
                "Radius",
                3f,
                new ConfigDescription(
                    "Radius of knockback effect",
                    new AcceptableValueRange<float>(0.1f, 20f)));
            KnockbackKey = Config.Bind("Controls", "KnockbackKey", KeyCode.Mouse0, "Key to trigger knockback (Mouse0 = Left Click)");
            DebugLogging = Config.Bind("Debug", "DebugLogging", false, "Enable verbose per-target logging");

            _cachedSceneName = SceneManager.GetActiveScene().name;
            SceneManager.activeSceneChanged += OnActiveSceneChanged;

            Logger.LogInfo($"{PluginName} v{PluginVersion} is loaded!");
        }

        private void Update()
        {
            if (!EnableMod.Value) return;

            if (Input.GetKeyDown(KnockbackKey.Value))
            {
                _pendingKnockback = true;
            }
        }

        private void FixedUpdate()
        {
            if (!EnableMod.Value || !_pendingKnockback) return;

            _pendingKnockback = false;
            ApplyKnockbackFromLocalPlayer();
        }

        private void ApplyKnockbackFromLocalPlayer()
        {
            try
            {
                // Try to find the local player's position
                GameObject localPlayer = GetLocalPlayer();
                if (localPlayer != null)
                {
                    Vector3 playerPos = localPlayer.transform.position;
                    ApplyKnockbackToNearbyPlayers(playerPos, localPlayer);
                    if (DebugLogging.Value)
                    {
                        Logger.LogInfo(
                            $"Knockback triggered from player at position {playerPos.ToString("F2", CultureInfo.InvariantCulture)}");
                    }
                }
                else
                {
                    Logger.LogWarning("Could not find local player for knockback");
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in ApplyKnockbackFromLocalPlayer: {ex}");
            }
        }

        private GameObject GetLocalPlayer()
        {
            string sceneName = SceneManager.GetActiveScene().name;
            if (!string.Equals(_cachedSceneName, sceneName, StringComparison.Ordinal))
            {
                _cachedSceneName = sceneName;
                _localPlayer = null;
            }

            if (_localPlayer != null && _localPlayer.activeInHierarchy)
            {
                return _localPlayer;
            }

            _localPlayer = ResolveLocalPlayer();
            return _localPlayer;
        }

        private GameObject ResolveLocalPlayer()
        {
            Camera cam = Camera.main;
            if (cam == null)
            {
                return null;
            }

            Vector3 center = cam.transform.position;
            float searchRadius = Mathf.Max(KnockbackRadius.Value * 3f, 30f);
            int count2D = Physics2D.OverlapCircleNonAlloc(center, searchRadius, _localSearchHits2D);
            for (int i = 0; i < count2D; i++)
            {
                GameObject candidate = GetGameObjectFromCollider(_localSearchHits2D[i]);
                if (IsLikelyPlayer(candidate))
                {
                    return candidate;
                }
            }

            int count3D = Physics.OverlapSphereNonAlloc(center, searchRadius, _localSearchHits3D);
            for (int i = 0; i < count3D; i++)
            {
                GameObject candidate = GetGameObjectFromCollider(_localSearchHits3D[i]);
                if (IsLikelyPlayer(candidate))
                {
                    return candidate;
                }
            }

            return null;
        }

        private bool HasPlayerComponents(GameObject obj)
        {
            if (obj == null) return false;

            // Check for common player components
            return obj.GetComponent<Rigidbody2D>() != null ||
                   obj.GetComponent<Rigidbody>() != null ||
                   obj.GetComponent<CharacterController>() != null ||
                   obj.GetComponent<Collider2D>() != null ||
                   obj.GetComponent<Collider>() != null;
        }
        
        private void ApplyKnockbackToNearbyPlayers(Vector3 sourcePosition, GameObject sourcePlayer)
        {
            try
            {
                int playersAffected = 0;
                var candidates = new HashSet<GameObject>();

                int count2D = Physics2D.OverlapCircleNonAlloc(sourcePosition, KnockbackRadius.Value, _hits2D);
                for (int i = 0; i < count2D; i++)
                {
                    GameObject candidate = GetGameObjectFromCollider(_hits2D[i]);
                    if (candidate != null)
                    {
                        candidates.Add(candidate);
                    }
                }

                int count3D = Physics.OverlapSphereNonAlloc(sourcePosition, KnockbackRadius.Value, _hits3D);
                for (int i = 0; i < count3D; i++)
                {
                    GameObject candidate = GetGameObjectFromCollider(_hits3D[i]);
                    if (candidate != null)
                    {
                        candidates.Add(candidate);
                    }
                }

                foreach (GameObject candidate in candidates)
                {
                    if (candidate == sourcePlayer) continue; // Don't knockback self

                    if (IsLikelyPlayer(candidate) && ApplyKnockbackToPlayer(candidate, sourcePosition))
                    {
                        playersAffected++;
                    }
                }

                Logger.LogInfo($"Applied knockback to {playersAffected} nearby players");
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in ApplyKnockbackToNearbyPlayers: {ex}");
            }
        }
        
        private bool IsLikelyPlayer(GameObject obj)
        {
            if (obj == null || !obj.activeInHierarchy) return false;

            string name = obj.name;
            bool nameLooksLikePlayer =
                name.IndexOf("player", StringComparison.OrdinalIgnoreCase) >= 0 ||
                name.IndexOf("character", StringComparison.OrdinalIgnoreCase) >= 0;

            return nameLooksLikePlayer && HasPlayerComponents(obj);
        }

        private static GameObject GetGameObjectFromCollider(Collider2D collider)
        {
            if (collider == null) return null;
            return collider.attachedRigidbody != null ? collider.attachedRigidbody.gameObject : collider.gameObject;
        }

        private static GameObject GetGameObjectFromCollider(Collider collider)
        {
            if (collider == null) return null;
            return collider.attachedRigidbody != null ? collider.attachedRigidbody.gameObject : collider.gameObject;
        }

        private bool ApplyKnockbackToPlayer(GameObject player, Vector3 sourcePosition)
        {
            try
            {
                Vector3 offset = player.transform.position - sourcePosition;
                if (offset.sqrMagnitude <= 0.01f)
                {
                    return false;
                }

                // Try Rigidbody2D first (most common for 2D games like UCH)
                Rigidbody2D rb2d = player.GetComponent<Rigidbody2D>();
                if (rb2d != null)
                {
                    Vector2 direction2D = new Vector2(offset.x, offset.y).normalized;
                    if (direction2D.sqrMagnitude <= 0f) return false;

                    Vector2 force2D = direction2D * KnockbackForce.Value;
                    rb2d.AddForce(force2D, ForceMode2D.Impulse);
                    if (DebugLogging.Value)
                    {
                        Logger.LogInfo($"Applied 2D knockback to {player.name} with force {force2D}");
                    }
                    return true;
                }

                // Try Rigidbody for 3D
                Rigidbody rb = player.GetComponent<Rigidbody>();
                if (rb != null)
                {
                    Vector3 force3D = offset.normalized * KnockbackForce.Value;
                    rb.AddForce(force3D, ForceMode.Impulse);
                    if (DebugLogging.Value)
                    {
                        Logger.LogInfo($"Applied 3D knockback to {player.name} with force {force3D}");
                    }
                    return true;
                }

                if (DebugLogging.Value)
                {
                    Logger.LogInfo($"Skipped knockback for {player.name}: no rigidbody attached");
                }
                return false;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error applying knockback to {player.name}: {ex}");
                return false;
            }
        }

        private void OnActiveSceneChanged(Scene oldScene, Scene newScene)
        {
            _cachedSceneName = newScene.name;
            _localPlayer = null;
        }

        private void OnDestroy()
        {
            SceneManager.activeSceneChanged -= OnActiveSceneChanged;
        }
    }
}
