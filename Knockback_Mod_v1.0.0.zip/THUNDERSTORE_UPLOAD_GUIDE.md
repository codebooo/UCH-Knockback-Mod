# Thunderstore Upload Guide for UCH Knockback Mod

## 📦 Package Ready!

Your mod has been packaged as: **UCH_Knockback_Mod_v1.0.0.zip**

## 🚀 How to Upload to Thunderstore

### 1. Create a Thunderstore Account
- Go to [thunderstore.io](https://thunderstore.io/)
- Sign up or log in
- Navigate to Ultimate Chicken Horse section

### 2. Upload Your Mod
1. Click "Upload" or "Publish Package"
2. Select the **UCH_Knockback_Mod_v1.0.0.zip** file
3. Fill in the required information:
   - **Name**: UCH Knockback Mod
   - **Description**: Adds player knockback functionality when left-clicking
   - **Category**: Mods
   - **Version**: 1.0.0

### 3. Optional: Add an Icon
- Create a 256x256 PNG image for your mod
- Name it `icon.png`
- Add it to the zip file before uploading

## 📋 Package Contents

The zip file contains:
- ✅ `manifest.json` - Mod metadata
- ✅ `README.md` - Documentation
- ✅ `CHANGELOG.md` - Version history
- ✅ `INSTALL.md` - Installation instructions
- ✅ `plugins/KnockbackMod.dll` - The actual mod

## 🎯 Sharing with Friends

Once uploaded to Thunderstore:
1. Share the Thunderstore link with your friends
2. They can install it via r2modman or Thunderstore Mod Manager
3. Everyone will have the knockback ability
4. Much better multiplayer experience!

## 🔧 If You Want to Test Locally First

You can share the zip file directly with friends:
1. Send them the `UCH_Knockback_Mod_v1.0.0.zip` file
2. They extract it and place `KnockbackMod.dll` in their `BepInEx/plugins/` folder
3. Test together to see if knockback works better with multiple players

## 💡 Why It Might Not Have Worked Before

- Ultimate Chicken Horse's networking might require server authority
- The host player might need the mod for physics to sync properly
- Having all players with the mod ensures consistent behavior

Good luck with your mod upload! 🐔🐴
