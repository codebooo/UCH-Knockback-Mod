# UCH Knockback Mod

A BepInEx mod for Ultimate Chicken Horse that adds player knockback functionality when left-clicking.

## 🎮 Features

- **Left-click knockback**: Hit or push other players by left-clicking near them
- **Configurable settings**: Adjust knockback force and radius through the config file
- **Multiplayer friendly**: Works best when all players have the mod installed
- **Safe implementation**: Uses Harmony patches to safely modify game behavior

## 📥 Installation

### Via r2modman/Thunderstore Mod Manager (Recommended)
1. Install r2modman or Thunderstore Mod Manager
2. Set it up for Ultimate Chicken Horse
3. Search for "UCH Knockback Mod" and install it
4. Launch the game through the mod manager

### Manual Installation
1. Make sure BepInEx is installed in your Ultimate Chicken Horse directory
2. Download the mod files
3. Place `KnockbackMod.dll` in `BepInEx/plugins/` folder
4. Launch the game

## 🎯 Usage

1. **Get close to other players** (within the configured radius - default 3 units)
2. **Left-click** to apply knockback force
3. **Players within range will be pushed away** from your position
4. **Best results when all players have the mod!**

## ⚙️ Configuration

After first launch, a config file will be created at `BepInEx/config/com.uchknockback.mod.cfg`

Available settings:
- **EnableMod**: Enable/disable the mod (default: true)
- **Force**: Knockback force strength (default: 15.0)
- **Radius**: Knockback effect radius (default: 3.0)
- **KnockbackKey**: Key to trigger knockback (default: Mouse0 - Left Click)

## 🔧 Troubleshooting

**Mod not working?**
1. Check that BepInEx is properly installed
2. Ensure the mod DLL is in the correct plugins folder
3. Check the BepInEx console/log for any error messages
4. Make sure all players have the mod for best results

**No knockback effect?**
1. Make sure you're within range of other players
2. Try increasing the Force setting in the config
3. Verify that other players also have the mod installed

## 🤝 Multiplayer Notes

- Works best when **all players have the mod installed**
- Only players with the mod can trigger knockback
- The effect should be visible to all players in the game
- Consider this for fair play in competitive matches

## 📋 Requirements

- Ultimate Chicken Horse
- BepInEx 5.4.21 or later

## 🐛 Known Issues

- May not work consistently if only one player has the mod
- Physics sync depends on the game's networking implementation

## 📝 Changelog

### v1.0.0
- Initial release
- Left-click knockback functionality
- Configurable force and radius
- r2modman/Thunderstore compatibility

---

**Have fun knocking your friends around! 🐔🐴**
