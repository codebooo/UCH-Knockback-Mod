# Changelog

## [1.0.0] - 2025-07-13
### Added
- Initial release of UCH Knockback Mod
- Left-click knockback functionality
- Configurable knockback force and radius
- Support for both 2D and 3D physics
- r2modman compatibility
- Automatic player detection
- Safe fallback mechanisms

### Features
- **Knockback Trigger**: Left mouse button (configurable)
- **Default Force**: 15.0 (configurable)
- **Default Radius**: 3.0 units (configurable)
- **Compatible with**: BepInEx 5.4.21+
- **Game Support**: Ultimate Chicken Horse
