# Changelog

## [1.0.1] - 2026-04-06
### Changed
- Added bounded config ranges for `Force` and `Radius`
- Updated plugin metadata to version `1.0.1`
- Replaced scene-wide object scans with overlap-based collider queries
- Added lazy local player caching with scene-change refresh
- Moved knockback trigger execution from `Update` to `FixedUpdate`
- Removed transform-position fallback for non-rigidbody targets
- Computed 2D knockback direction explicitly on planar axes
- Added `DebugLogging` config toggle and guarded verbose logs
- Removed unused Harmony patch initialization until explicit patches exist

## [1.0.0] - 2025-07-13
### Added
- Initial release of UCH Knockback Mod
- Left-click knockback functionality
- Configurable knockback force and radius
- Support for both 2D and 3D physics
- r2modman compatibility
- Automatic player detection
- Safe fallback mechanisms

### Features
- **Knockback Trigger**: Left mouse button (configurable)
- **Default Force**: 15.0 (configurable)
- **Default Radius**: 3.0 units (configurable)
- **Compatible with**: BepInEx 5.4.21+
- **Game Support**: Ultimate Chicken Horse
