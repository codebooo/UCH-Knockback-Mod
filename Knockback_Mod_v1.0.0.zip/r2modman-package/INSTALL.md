# UCH Knockback Mod - Installation and Usage

## Quick Start

### Via r2modman (Recommended)
1. Download and install [r2modman](https://github.com/ebkr/r2modmanPlus/releases)
2. Add Ultimate Chicken Horse as a game in r2modman
3. Install this mod through the mod manager
4. Launch the game through r2modman

### Manual Installation
1. Ensure BepInEx 5.4.21+ is installed in your Ultimate Chicken Horse directory
2. Download `KnockbackMod.dll` from the releases
3. Place the DLL file in `BepInEx/plugins/` folder
4. Launch the game

## How to Use

1. **Start the game** - The mod will load automatically and create a config file
2. **Get close to other players** - The knockback effect works within a configurable radius (default: 3 units)
3. **Left-click** - Press the left mouse button to apply knockback force to nearby players
4. **Configure settings** - Edit the config file at `BepInEx/config/com.uchknockback.mod.cfg`

## Configuration Options

The mod creates a configuration file at `BepInEx/config/com.uchknockback.mod.cfg` with these settings:

```ini
[General]
EnableMod = true

[Knockback]
Force = 15.0
Radius = 3.0

[Controls]
KnockbackKey = Mouse0
```

### Settings Explained

- **EnableMod**: Turn the mod on/off without removing it
- **Force**: How strong the knockback is (higher = stronger push)
- **Radius**: How far away players can be and still get knocked back
- **KnockbackKey**: Which key triggers the knockback (Mouse0 = Left Click)

### Available Keys
You can change the knockback key to any of these:
- `Mouse0` (Left Click)
- `Mouse1` (Right Click) 
- `Mouse2` (Middle Click)
- `Space` (Spacebar)
- `E`, `F`, `Q`, etc. (Any letter key)
- And many more Unity KeyCodes

## Troubleshooting

### Mod Not Working
1. Check that BepInEx is properly installed and working
2. Verify `KnockbackMod.dll` is in the `BepInEx/plugins/` folder
3. Check the BepInEx console/log for error messages
4. Make sure EnableMod is set to `true` in the config

### No Effect on Players
1. Make sure you're within the knockback radius of other players
2. Try increasing the Force value in the config
3. Check if the target players have physics components (the mod will log this)

### Performance Issues
1. The mod searches for players each time you click - this is normal
2. If you experience lag, try reducing the search frequency by using the key less often

## Compatibility

- **Game Version**: Works with current Ultimate Chicken Horse versions
- **BepInEx**: Requires version 5.4.21 or later
- **Other Mods**: Should be compatible with most other UCH mods
- **Multiplayer**: Works in multiplayer games

## Uninstallation

### Via r2modman
Simply disable or uninstall the mod through the mod manager.

### Manual
Delete `KnockbackMod.dll` from the `BepInEx/plugins/` folder.

## Support

If you encounter issues:
1. Check the troubleshooting section above
2. Look at the BepInEx logs for error messages
3. Report bugs with details about your setup and what happened

## Technical Details

The mod works by:
1. Detecting when you press the configured key
2. Finding your player character in the game
3. Searching for other player objects within the specified radius
4. Applying physics forces to push them away from your position
5. Using multiple fallback methods to ensure compatibility

The mod safely handles different physics systems and will log what methods it uses for debugging.
