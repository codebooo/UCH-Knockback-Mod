@echo off
echo ======================================
echo UCH Knockback Mod - Build and Package
echo ======================================
echo.

set GAME_DIR=d:\SteamLibrary\steamapps\common\Ultimate Chicken Horse
set PROJECT_DIR=%~dp0

echo Building mod...
dotnet build -c Release

if %ERRORLEVEL% NEQ 0 (
    echo Build failed!
    pause
    exit /b 1
)

echo.
echo Installing to game...
copy "bin\Release\net472\KnockbackMod.dll" "%GAME_DIR%\BepInEx\plugins\"

echo.
echo Creating r2modman package...
copy "bin\Release\net472\KnockbackMod.dll" "r2modman-package\plugins\"

echo.
echo ======================================
echo Build Complete!
echo ======================================
echo.
echo Files created:
echo - KnockbackMod.dll (installed to game)
echo - r2modman-package\ (ready for distribution)
echo.
echo To use the mod:
echo 1. Start Ultimate Chicken Horse
echo 2. Get close to other players 
echo 3. Left-click to apply knockback
echo.
echo Configuration file will be created at:
echo %GAME_DIR%\BepInEx\config\com.uchknockback.mod.cfg
echo.
echo For r2modman distribution:
echo 1. Add an icon.png (256x256) to r2modman-package\
echo 2. Zip the r2modman-package folder contents
echo 3. Upload to mod repositories
echo.
pause
