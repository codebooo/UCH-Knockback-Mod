@echo off
echo Compiling UCH Knockback Mod...

set GAME_DIR=d:\SteamLibrary\steamapps\common\Ultimate Chicken Horse
set MANAGED_DIR=%GAME_DIR%\UltimateChickenHorse_Data\Managed
set BEPINEX_DIR=%GAME_DIR%\BepInEx\core
set CSC_PATH=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe

echo Using C# compiler: %CSC_PATH%
echo Game directory: %GAME_DIR%

if not exist "%CSC_PATH%" (
    echo C# compiler not found at %CSC_PATH%
    echo Trying 32-bit version...
    set CSC_PATH=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe
)

if not exist "%CSC_PATH%" (
    echo C# compiler not found! Please install .NET Framework or Visual Studio.
    pause
    exit /b 1
)

echo Compiling plugin...

"%CSC_PATH%" ^
    /target:library ^
    /out:KnockbackMod.dll ^
    /reference:"%MANAGED_DIR%\UnityEngine.dll" ^
    /reference:"%MANAGED_DIR%\UnityEngine.CoreModule.dll" ^
    /reference:"%MANAGED_DIR%\UnityEngine.InputLegacyModule.dll" ^
    /reference:"%MANAGED_DIR%\UnityEngine.PhysicsModule.dll" ^
    /reference:"%MANAGED_DIR%\UnityEngine.Physics2DModule.dll" ^
    /reference:"%BEPINEX_DIR%\BepInEx.dll" ^
    /reference:"%BEPINEX_DIR%\0Harmony.dll" ^
    KnockbackPlugin.cs

if %ERRORLEVEL% EQU 0 (
    echo Compilation successful!
    echo Copying DLL to plugins folder...
    copy KnockbackMod.dll "%GAME_DIR%\BepInEx\plugins\"
    echo Mod installed successfully!
    echo.
    echo Configuration will be created in: %GAME_DIR%\BepInEx\config\com.uchknockback.mod.cfg
    echo.
    echo To use the mod:
    echo 1. Start Ultimate Chicken Horse
    echo 2. Get close to other players
    echo 3. Left-click to apply knockback
) else (
    echo Compilation failed!
)

pause
