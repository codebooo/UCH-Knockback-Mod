@echo off
echo Building UCH Knockback Mod...

set GAME_DIR=d:\SteamLibrary\steamapps\common\Ultimate Chicken Horse
set PROJECT_DIR=%~dp0

echo Game Directory: %GAME_DIR%
echo Project Directory: %PROJECT_DIR%

dotnet build "%PROJECT_DIR%KnockbackMod.csproj" -p:GameDir="%GAME_DIR%" -c Release

if %ERRORLEVEL% EQU 0 (
    echo Build successful!
    echo Copying DLL to plugins folder...
    copy "%PROJECT_DIR%bin\Release\net472\KnockbackMod.dll" "%GAME_DIR%\BepInEx\plugins\"
    echo Mod installed successfully!
) else (
    echo Build failed!
)

pause
